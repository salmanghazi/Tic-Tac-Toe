/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assign4;

import javax.swing.ImageIcon;

/**
 *
 * @author m.salmanghazi
 */
public class Model extends TTModel {

    public Model(ImageIcon tick) {
    }
    
}
